import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  const Login({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('images/background.jpg'), fit: BoxFit.cover)),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              elevation: 8.0,
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Image.asset('images/logo.png', width: 200),
                      TextFormField(
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(
                            labelText: 'Usuario',
                            labelStyle: TextStyle(color: Colors.black),
                            focusedBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Color(0xFFEE7600)))),
                      ),
                      SizedBox(height: 30.0),
                      TextFormField(
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(
                            labelText: 'Contraseña',
                            labelStyle: TextStyle(color: Colors.black),
                            focusedBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Color(0xFFEE7600)))),
                      ),
                      SizedBox(height: 40.0),
                      ElevatedButton(
                        onPressed: () {
                          // Lógica para el inicio de sesión
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Color(
                              0xFFCF2924), // Color personalizado de fondo del botón
                        ),
                        child: Text('Iniciar sesión',
                            style: TextStyle(fontSize: 18)),
                      ),
                      SizedBox(height: 10.0),
                      TextButton(
                        onPressed: () {
                          // Lógica para redirigir a la recuperación de contraseña
                        },
                        child: Text('¿Olvidaste tu contraseña?',
                            style: TextStyle(color: Colors.black)),
                      ),
                      TextButton(
                        onPressed: () {
                          // Lógica para redirigir al registro de cuenta
                        },
                        child: Text('¿Aún no tienes una cuenta?',
                            style: TextStyle(color: Colors.black)),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ),
    );
  }
}
